# Ancillary exact checks for rank-six positivity

Version: rank-six-2026-09-25-v1. These are exact campaign-owned checking
programs and inert mathematical data. They establish the stated finite
components; the manuscript supplies the geometric/analytic implication.

From this directory, choose fresh output paths outside the source tree:

```sh
python3 -B verify_closure.py --certificate CLOSURE-CERTIFICATE.json --atlas atlas.json --out /path/to/new-closure-check
c++ -std=c++17 -O3 minimum_six.cpp -o /path/to/minimum-six
/path/to/minimum-six /path/to/new-closure-check/EXHAUSTION.txt
python3 -B test_constructive_hive_closure.py --certificate CLOSURE-CERTIFICATE.json --atlas atlas.json --verification-receipt /path/to/new-closure-check/RESULT.json
python3 -B small_rank_six/verify.py small --out /path/to/new-small-check
```

The closure proof covers all 2^45 physical-row seeds; the separate native
step checks all 1,385,980 smaller seeds for the minimum-six obstruction.
The small coefficient command checks complete c6–c9 finite premises using
two scalar algorithms. It requires Python 3.11+, POSIX process groups, C++17
and GMP development headers/libraries; use --gmp-prefix when necessary.
The closure and constructive Python programs use only the standard library.
Keep Python assertions enabled. No program installs software or uses a network.

The full c1–c5 data and analytic scalar regeneration are separate required
components in the versioned public repository release. Consult the paper's
verification link for complete commands, hashes and measured costs. The
ancillary subset alone is not the whole coefficient proof. No proof-assistant
formalization or external human peer review is asserted.

Code is MIT-licensed; non-code original research data are CC BY 4.0 under the
project's existing licensing policy. The included license texts apply to those
respective scopes. Credit Chris Hadad and the stated mathematical/AI
contributions, with classical sources as cited in the paper.
